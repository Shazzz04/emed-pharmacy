</main>
<footer>
    <p>&copy; <?php echo date("Y"); ?> e-Med Pharmacy. All Rights Reserved.</p>
</footer>
</body>
</html>
