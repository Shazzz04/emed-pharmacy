<?php
include 'header.php';
include 'functions.php';

$product = new Product();
$products = $product->getAllProducts();
?>
<h2>Products</h2>
<div>
<?php foreach($products as $p): ?>
    <div>
        <h3><?php echo $p['name']; ?></h3>
        <p>Price: $<?php echo $p['price']; ?></p>
        <a href="cart.php?add=<?php echo $p['id']; ?>">Add to Cart</a>
    </div>
<?php endforeach; ?>
</div>
<?php include 'footer.php'; ?>
