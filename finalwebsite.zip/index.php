<?php include 'header.php'; ?>
<h1>Welcome to e-Med Pharmacy</h1>
<p>Browse products and upload prescriptions easily!</p>
<a href="product.php">Shop Now</a>
<?php include 'footer.php'; ?>
