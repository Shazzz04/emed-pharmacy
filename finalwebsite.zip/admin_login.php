<?php
include 'header.php';
include 'functions.php';
$user = new User();
if(isset($_POST['submit'])){
    $email = $_POST['email'];
    $password = $_POST['password'];
    $login = $user->login($email,$password);
    if($login && $login['role']=="admin"){
        session_start();
        $_SESSION['admin'] = $login;
        echo "<p>Admin login successful!</p>";
    } else {
        echo "<p>Invalid credentials!</p>";
    }
}
?>
<h2>Admin Login</h2>
<form method="POST">
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <input type="submit" name="submit" value="Login">
</form>
<?php include 'footer.php'; ?>
