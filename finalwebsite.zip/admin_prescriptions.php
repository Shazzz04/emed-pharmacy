<?php
include 'header.php';
require_once 'functions.php';

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare("SELECT p.id, u.name AS customer, p.file_name, p.status 
                        FROM prescriptions p 
                        JOIN users u ON p.user_id = u.id 
                        ORDER BY p.id DESC");
$stmt->execute();
$prescriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Uploaded Prescriptions</h2>
<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Customer</th>
        <th>File</th>
        <th>Status</th>
    </tr>
    <?php foreach ($prescriptions as $prescription): ?>
    <tr>
        <td><?php echo $prescription['id']; ?></td>
        <td><?php echo $prescription['customer']; ?></td>
        <td><a href="uploads/<?php echo $prescription['file_name']; ?>" target="_blank">View</a></td>
        <td><?php echo $prescription['status']; ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<?php include 'footer.php'; ?>
