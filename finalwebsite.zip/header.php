<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>e-Med Pharmacy</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Dynamic CSS (Customer vs Admin) -->
    <?php
        $currentPage = basename($_SERVER['PHP_SELF']); // get current file name
        if (strpos($currentPage, 'admin') !== false) {
            // If filename contains 'admin' → load admin CSS
            echo '<link rel="stylesheet" href="css/style_admin.css">';
        } else {
            // Otherwise → load customer CSS
            echo '<link rel="stylesheet" href="css/style_customer.css">';
        }
    ?>
</head>
<body>
    
    <!-- Navbar -->
    <header>
        <nav class="navbar navbar-expand-lg 
            <?php echo (strpos($currentPage, 'admin') !== false) ? 'navbar-dark bg-dark' : 'navbar-dark bg-success'; ?> shadow">
            
            <div class="container-fluid">
                <a class="navbar-brand fw-bold" 
                   href="<?php echo (strpos($currentPage, 'admin') !== false) ? 'admin_dashboard.php' : 'index.php'; ?>">
                   <?php echo (strpos($currentPage, 'admin') !== false) ? 'Admin Panel' : 'e-Med Pharmacy'; ?>
                </a>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
                        data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" 
                        aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <?php if (strpos($currentPage, 'admin') !== false): ?>
                            <!-- Admin Menu -->
                            <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Dashboard</a></li>
                            <li class="nav-item"><a class="nav-link" href="admin_products.php">Manage Products</a></li>
                            <li class="nav-item"><a class="nav-link" href="admin_orders.php">Orders</a></li>
                            <li class="nav-item"><a class="nav-link" href="admin_prescriptions.php">Prescriptions</a></li>
                            <li class="nav-item"><a class="nav-link" href="admin_logout.php">Logout</a></li>
                        <?php else: ?>
                            <!-- Customer Menu -->
                            <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="product.php">Products</a></li>
                            <li class="nav-item"><a class="nav-link" href="cart.php">Cart</a></li>
                            <li class="nav-item"><a class="nav-link" href="orders.php">Orders</a></li>
                            <li class="nav-item"><a class="nav-link" href="upload_prescription.php">Upload Prescription</a></li>
                            <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                            <li class="nav-item"><a class="nav-link" href="register.php">Register</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!-- Page Content -->
    <main class="container mt-4">
