<?php
include 'header.php';
include 'functions.php';

$user = new User();
if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    if($user->register($name,$email,$password)){
        echo "<p>Registration successful!</p>";
    } else {
        echo "<p>Error registering user.</p>";
    }
}
?>
<h2>Register</h2>
<form method="POST">
    <input type="text" name="name" placeholder="Name" required><br>
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <input type="submit" name="submit" value="Register">
</form>
<?php include 'footer.php'; ?>
