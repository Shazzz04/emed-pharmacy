<?php
require_once 'db.php';

class User {
    private $conn;
    private $table = "users";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->connect();
    }

    public function register($name,$email,$password,$role="customer"){
        $hashed = password_hash($password, PASSWORD_BCRYPT);
        $query = "INSERT INTO $this->table (name,email,password,role) VALUES (:name,:email,:password,:role)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':name',$name);
        $stmt->bindParam(':email',$email);
        $stmt->bindParam(':password',$hashed);
        $stmt->bindParam(':role',$role);
        return $stmt->execute();
    }

    public function login($email,$password){
        $query = "SELECT * FROM $this->table WHERE email=:email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email',$email);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if($user && password_verify($password, $user['password'])) return $user;
        return false;
    }
}

class Product {
    private $conn;
    private $table = "products";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->connect();
    }

    public function getAllProducts() {
        $query = "SELECT * FROM $this->table";
        $stmt = $this->conn->query($query);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

class Order {
    private $conn;
    private $table = "orders";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->connect();
    }
}

class Prescription {
    private $conn;
    private $table = "prescriptions";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->connect();
    }

    public function uploadPrescription($user_id, $filename){
        $query = "INSERT INTO $this->table (user_id,file_name) VALUES (:user_id,:file_name)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id',$user_id);
        $stmt->bindParam(':file_name',$filename);
        return $stmt->execute();
    }
}
?>
