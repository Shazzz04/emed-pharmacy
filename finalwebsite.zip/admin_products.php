<?php
include 'header.php';
include 'functions.php';
session_start();
if(!isset($_SESSION['admin'])) header("Location: admin_login.php");

$product = new Product();

// For now, just display products
$products = $product->getAllProducts();
?>
<h2>Manage Products</h2>
<a href="admin_add_product.php">Add Product</a>
<table border="1" cellpadding="10">
<tr><th>ID</th><th>Name</th><th>Price</th><th>Action</th></tr>
<?php foreach($products as $p): ?>
<tr>
    <td><?php echo $p['id']; ?></td>
    <td><?php echo $p['name']; ?></td>
    <td>$<?php echo $p['price']; ?></td>
    <td><a href="admin_edit_product.php?id=<?php echo $p['id']; ?>">Edit</a> | <a href="#">Delete</a></td>
</tr>
<?php endforeach; ?>
</table>
<?php include 'footer.php'; ?>
