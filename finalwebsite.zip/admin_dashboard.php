<?php
include 'header.php';
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: admin_login.php");
    exit;
}
?>
<h2>Admin Dashboard</h2>
<ul>
    <li><a href="admin_products.php">Manage Products</a></li>
    <li><a href="admin_orders.php">Manage Orders</a></li>
    <li><a href="admin_prescriptions.php">Manage Prescriptions</a></li>
    <li><a href="logout.php">Logout</a></li>
</ul>
<?php include 'footer.php'; ?>
