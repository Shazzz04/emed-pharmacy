<?php
include 'header.php';
include 'functions.php';
session_start();

$order = new Order();
// For now, simulate order history
$orders = [
    ['id'=>1, 'product'=>'Bioderma', 'quantity'=>1, 'total'=>55],
    ['id'=>2, 'product'=>'Umcka Cold Care', 'quantity'=>2, 'total'=>240],
];
?>
<h2>My Orders</h2>
<?php if(empty($orders)): ?>
<p>No orders yet.</p>
<?php else: ?>
<table border="1" cellpadding="10">
    <tr><th>Order ID</th><th>Product</th><th>Quantity</th><th>Total</th></tr>
    <?php foreach($orders as $o): ?>
    <tr>
        <td><?php echo $o['id']; ?></td>
        <td><?php echo $o['product']; ?></td>
        <td><?php echo $o['quantity']; ?></td>
        <td>$<?php echo $o['total']; ?></td>
    </tr>
    <?php endforeach; ?>
</table>
<?php endif; ?>
<?php include 'footer.php'; ?>
