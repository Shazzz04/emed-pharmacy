<?php
include 'header.php';
require_once 'functions.php';

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare("SELECT o.id, u.name AS customer, o.total_amount, o.status 
                        FROM orders o 
                        JOIN users u ON o.user_id = u.id 
                        ORDER BY o.id DESC");
$stmt->execute();
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>All Orders</h2>
<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Customer</th>
        <th>Total Amount</th>
        <th>Status</th>
    </tr>
    <?php foreach ($orders as $order): ?>
    <tr>
        <td><?php echo $order['id']; ?></td>
        <td><?php echo $order['customer']; ?></td>
        <td><?php echo $order['total_amount']; ?></td>
        <td><?php echo $order['status']; ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<?php include 'footer.php'; ?>
