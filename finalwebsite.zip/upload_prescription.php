<?php
include 'header.php';
include 'functions.php';
session_start();
$prescription = new Prescription();

if(isset($_POST['submit'])){
    $file = $_FILES['prescription']['name'];
    $tmp = $_FILES['prescription']['tmp_name'];
    move_uploaded_file($tmp, "uploads/".$file);
    $prescription->uploadPrescription($_SESSION['user']['id'],$file);
    echo "<p>Prescription uploaded successfully!</p>";
}
?>
<h2>Upload Prescription</h2>
<form method="POST" enctype="multipart/form-data">
    <input type="file" name="prescription" required><br>
    <input type="submit" name="submit" value="Upload">
</form>
<?php include 'footer.php'; ?>
